import profile from "../assets/images/profile.jpg";

export default {
  profile,
};
